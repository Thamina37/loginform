<?php

  session_start();

  if(isset($_SESSION['success'])){
     header('location: output.php');
  }

  if(isset($_POST['submit'])){
     
    $email = $_POST['email'];
    $password = $_POST['password'];

    define('EMAIL', 'admin@gmail.com');
    define('PASSWORD', '333');

    if( $email == EMAIL &&  $password == PASSWORD){
        
        $_SESSION['success'] = 'successfully log in';

        header('location: output.php');
    }
    else{
        $fail = 'password does not match';
    }
  }



?>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
   <form action="" method = 'POST' >
     <input type="email" name = 'email' placeholder = 'email'>
     <input type="password" name = 'password' placeholder = 'password' required>
     <input type="submit" name = 'submit' value = 'submit'>
   </form>


   <p>
    <?php
       if(isset($fail)) {
        echo $fail;
       } 
    ?>
   </p>

</body>
</html>